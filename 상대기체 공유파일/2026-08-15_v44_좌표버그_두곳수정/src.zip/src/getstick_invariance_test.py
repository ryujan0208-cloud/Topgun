# -*- coding: utf-8 -*-
"""GetStick 불변성 시험.
[원리] 상대 기하가 같으면(내 자세, 나->VP 상대벡터 동일) 스틱 출력도 같아야 한다.
  절대 위치만 바꿨는데 출력이 달라지면 = 위치에 좌표변환이 걸려 있다는 뜻."""
import sys, os, ctypes as ct
sys.path.insert(0,"."); sys.path.insert(0,"src")
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
for k in ("TOPGUN_RULE","TOPGUN_ABLATE","TOPGUN_MATCH","TOPGUN_WEZ"): os.environ.pop(k,None)
from dogfight.ai.native_bt import AIPilot, OPlaneData

class ControlValue(ct.Structure):
    _fields_=[("RollCMD",ct.c_float),("PitchCMD",ct.c_float),("RudderCMD",ct.c_float),("Throttle",ct.c_float)]

dll=sys.argv[1]
ap=AIPilot(dll); ap.CreateBehaviorTree(0,1)
lib=ap.AIPilotDLL
lib.GetStick.restype=ControlValue
lib.GetStick.argtypes=[ct.POINTER(OPlaneData), ct.c_float, ct.c_float, ct.c_float]

def stick(px,py,pz, vx,vy,vz):
    p=OPlaneData()
    p.LocationX=float(px); p.LocationY=float(py); p.LocationZ=float(pz)
    p.Roll=0.0; p.Pitch=0.0; p.Yaw=0.0
    p.Speed=200.0; p.Resv0=0.0; p.Resv1=100.0; p.Resv2=0.0
    r=lib.GetStick(ct.byref(p), ct.c_float(vx), ct.c_float(vy), ct.c_float(vz))
    return (r.RollCMD, r.PitchCMD, r.RudderCMD)

# A: 원점 근처.  B: 25km 밖.  둘 다 VP는 '내 위치 + 같은 상대벡터'
REL=(1000.0, 0.0, 0.0)
A=(0.0,0.0,5000.0);        VA=tuple(A[i]+REL[i] for i in range(3))
B=(25000.0,-18000.0,5000.0); VB=tuple(B[i]+REL[i] for i in range(3))
sa=stick(*A,*VA); sb=stick(*B,*VB)
same = all(abs(x-y)<1e-4 for x,y in zip(sa,sb))
print(f"{dll:26} A(원점) ({sa[0]:+.4f},{sa[1]:+.4f},{sa[2]:+.4f})  B(25km) ({sb[0]:+.4f},{sb[1]:+.4f},{sb[2]:+.4f})  {'같음 ✅ 변환없음' if same else '다름 🔴 변환함'}")
